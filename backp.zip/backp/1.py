# pages/1_📋_Asset_List.py

import streamlit as st
import pandas as pd
import csv
from sqlalchemy import create_engine
from config import DATABASE_URL
from auth import require_windows_login
from io import StringIO

# Require login
require_windows_login()

# Page title
st.title("📋 Asset Inventory")

# Connect to PostgreSQL
db_engine = create_engine(DATABASE_URL)

# Define column length limits (based on PostgreSQL schema)
column_limits = {
    "vni_asset_number": 50,
    "license_id": 50,
    "category": 50,
    "manufacturer": 100,
    "description": 255,
    "project_name": 100,
    "domain_name": 50,
    "team_name": 50,
    "current_user_id": 100,  # Extended to allow full emails
    "status": 20,
    "verified_by": 100
    # Dates and asset_id are excluded from length checks
}


# 🔎 Helper: validate column lengths
def validate_column_lengths(df, limits):
    errors = []
    for col, max_len in limits.items():
        if col in df.columns:
            too_long = df[col].dropna().astype(str).apply(lambda x: len(x) > max_len)
            if too_long.any():
                rows = too_long[too_long].index.tolist()
                errors.append(f"❌ Column '{col}' has values exceeding {max_len} characters at rows: {rows}")
    return errors


# 📤 Upload CSV (admin only)
if st.session_state.get("role") == "admin":
    st.subheader("📤 Upload Asset CSV")
    uploaded_file = st.file_uploader("Choose a tab-separated .tsv or .csv file", type=["csv", "tsv"], key="asset_csv")

    if uploaded_file is not None:
        try:
            content = uploaded_file.read().decode("utf-8", errors="ignore")
            preview_lines = "\n".join(content.splitlines()[:5])
            st.text("📄 File Preview:\n" + preview_lines)

            # Parse as tab-separated
            df_upload = pd.read_csv(StringIO(content), delimiter="\t", quoting=csv.QUOTE_NONE, engine="python")
            # 👉 Fix header BOM issues
            df_upload.columns = df_upload.columns.str.replace('\ufeff', '', regex=True).str.strip()
            # Validate column lengths
            validation_errors = validate_column_lengths(df_upload, column_limits)
            if validation_errors:
                st.error("❌ Column length issues found:\n" + "\n".join(validation_errors))
                st.stop()

            # Load existing asset_id and license_id to avoid duplicates
            existing = pd.read_sql("SELECT asset_id, license_id FROM assets_table", db_engine)
            existing_asset_ids = set(existing['asset_id'].dropna().astype(str))
            existing_license_ids = set(existing['license_id'].dropna().astype(str))

            df_upload['asset_id'] = df_upload['asset_id'].astype(str)
            df_upload['license_id'] = df_upload['license_id'].astype(str)

            df_filtered = df_upload[
                ~df_upload['asset_id'].isin(existing_asset_ids) &
                ~df_upload['license_id'].isin(existing_license_ids)
            ]

            if df_filtered.empty:
                st.warning("⚠️ No new records to upload. All asset_id or license_id values already exist.")
            else:
                df_filtered.to_sql("assets_table", db_engine, if_exists="append", index=False)
                st.success(f"✅ Uploaded {len(df_filtered)} new records.")
                st.dataframe(df_filtered)

        except Exception as e:
            st.error(f"❌ Upload or parsing failed: {e}")


# 📦 Load asset data from DB
@st.cache_data(ttl=300)
def load_assets():
    try:
        return pd.read_sql("SELECT * FROM assets_table ORDER BY added_on DESC", db_engine)
    except Exception as e:
        st.warning(f"⚠️ Failed to load data: {e}")
        return pd.DataFrame()


df = load_assets()

# 🔍 Filter UI
if not df.empty:
    with st.expander("🔍 Filter Options", expanded=False):
        col1, col2, col3, col4 = st.columns(4)
        project_filter = col1.selectbox("Project", ["All"] + sorted(df.project_name.dropna().unique().tolist()))
        domain_filter = col2.selectbox("Domain", ["All"] + sorted(df.domain_name.dropna().unique().tolist()))
        team_filter = col3.selectbox("Team", ["All"] + sorted(df.team_name.dropna().unique().tolist()))
        status_filter = col4.selectbox("Status", ["All"] + sorted(df.status.dropna().unique().tolist()))

        col5, col6, col7, col8 = st.columns(4)
        vni_filter = col5.selectbox("VNI Asset Number", ["All"] + sorted(df.vni_asset_number.dropna().unique().tolist()))
        license_filter = col6.selectbox("License ID", ["All"] + sorted(df.license_id.dropna().unique().tolist()))
        category_filter = col7.selectbox("Category", ["All"] + sorted(df.category.dropna().unique().tolist()))
        mfr_filter = col8.selectbox("Manufacturer", ["All"] + sorted(df.manufacturer.dropna().unique().tolist()))

    # Apply filters
    if project_filter != "All":
        df = df[df.project_name == project_filter]
    if domain_filter != "All":
        df = df[df.domain_name == domain_filter]
    if team_filter != "All":
        df = df[df.team_name == team_filter]
    if status_filter != "All":
        df = df[df.status == status_filter]
    if vni_filter != "All":
        df = df[df.vni_asset_number == vni_filter]
    if license_filter != "All":
        df = df[df.license_id == license_filter]
    if category_filter != "All":
        df = df[df.category == category_filter]
    if mfr_filter != "All":
        df = df[df.manufacturer == mfr_filter]

    # Show results
    st.subheader(f"📦 {len(df)} Asset(s) Found")
    st.dataframe(df, use_container_width=True, height=500)
else:
    st.info("ℹ️ No data available in the assets_table.")
