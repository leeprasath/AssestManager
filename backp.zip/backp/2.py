import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from config import DATABASE_URL
from auth import require_windows_login

# --------------------- 🔐 Login Required ---------------------


require_windows_login()


# --------------------- 📄 Page Config ---------------------
st.set_page_config(
    page_title="📦 Asset Upload Dashboard",
    page_icon="📦",
    layout="wide"
)

st.title("📦 Asset Upload Dashboard")

# --------------------- 🔌 Connect to DB ---------------------
try:
    engine = create_engine(DATABASE_URL)
    with engine.connect() as conn:
        df_assets = pd.read_sql("SELECT * FROM assets_table", conn)
except Exception as e:
    st.error(f"❌ Failed to connect to database: {e}")
    st.stop()

# --------------------- 📤 Upload Section ---------------------
if st.session_state.role == "admin":
    st.sidebar.header("📤 Upload Assets Data")
    uploaded_file = st.sidebar.file_uploader("Upload Asset CSV", type=["csv"])

    if uploaded_file:
        df_upload = pd.read_csv(uploaded_file)

        st.subheader("🔍 Preview of Uploaded Data")
        st.dataframe(df_upload.head(10), use_container_width=True)

        required_columns = [
            "asset_id", "vni_asset_number", "license_id", "category", "manufacturer", "description",
            "project_name", "domain_name", "team_name", "current_user_id", "status",
            "expiry_date", "calibration_date", "verified_by", "added_on"
        ]

        if not all(col in df_upload.columns for col in required_columns):
            st.error("❌ CSV is missing one or more required columns.")
        else:
            try:
                # Safely parse date columns
                df_upload["added_on"] = pd.to_datetime(df_upload["added_on"], errors="coerce")
                df_upload["expiry_date"] = pd.to_datetime(df_upload["expiry_date"], errors="coerce")
                df_upload["calibration_date"] = pd.to_datetime(df_upload["calibration_date"], errors="coerce")

                # Drop rows without essential keys
                df_upload.dropna(subset=["vni_asset_number"], inplace=True)

                with engine.begin() as conn:
                    df_upload.to_sql("assets_table", conn, if_exists="append", index=False)

                st.success(f"✅ Uploaded {len(df_upload)} records to assets_table.")
                st.experimental_rerun()
            except Exception as e:
                st.error(f"❌ Failed to insert into database: {e}")

# --------------------- 📋 Existing Assets Table ---------------------
st.subheader("📋 Existing Records in assets_table")
st.dataframe(df_assets.head(50), use_container_width=True)

