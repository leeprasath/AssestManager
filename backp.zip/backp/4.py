import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text
from config import DATABASE_URL
from auth import require_windows_login, is_admin

# --------------------- 🔐 Require Login ---------------------
require_windows_login()

# --------------------- ⚙️ DB Connection ---------------------
engine = create_engine(DATABASE_URL)

# --------------------- 📄 Page Config ---------------------
st.set_page_config(page_title="📦 Asset List Upload", page_icon="📦", layout="wide")
st.title("📦 Asset Upload Dashboard")

def dropdown_with_new(label, suggestions, key_prefix=""):
    selected = st.selectbox(
        f"{label}",
        ["<New>"] + suggestions,
        key=f"{key_prefix}_dropdown"
    )
    is_new = selected == "<New>"

    new_value = st.text_input(
        f"Enter new {label}",
        disabled=not is_new,
        placeholder="Type new value...",
        key=f"{key_prefix}_textinput"
    )
    return new_value if is_new else selected

# --------------------- 🔁 Reusable Upload Function ---------------------
def upload_csv_to_table(upload_label, required_columns, db_table_name, parse_dates=None):
    uploaded_file = st.file_uploader(f"Upload CSV for `{db_table_name}`", type=["csv"], key=db_table_name)

    if uploaded_file:
        df_upload = pd.read_csv(uploaded_file)
        st.write("🔍 Preview of Uploaded Data")
        st.dataframe(df_upload.head(10), use_container_width=True)

        if not all(col in df_upload.columns for col in required_columns):
            st.error("❌ CSV is missing one or more required columns.")
            return

        try:
            if parse_dates:
                for date_col in parse_dates:
                    df_upload[date_col] = pd.to_datetime(df_upload[date_col], errors="coerce")

            if "license_id" in df_upload.columns:
                df_upload["license_id"] = df_upload["license_id"].apply(
                    lambda x: str(int(float(x))) if pd.notnull(x) and str(x).replace('.', '', 1).isdigit() else None
                )

            if db_table_name == "assets_table":
                df_upload.dropna(subset=["vni_asset_number"], inplace=True)

            if st.button(f"⬆️ Upload to `{db_table_name}`"):
                with engine.begin() as conn:
                    conn.execute(text(f"DELETE FROM {db_table_name}"))
                    df_upload.to_sql(db_table_name, conn, if_exists="append", index=False)
                st.success(f"✅ Successfully uploaded {len(df_upload)} records to `{db_table_name}`.")
                st.rerun()
        except Exception as e:
            st.error(f"❌ Upload failed: {e}")

# --------------------- 🔒 Admin Uploads ---------------------
# Add Modify Entry tab
if is_admin():
    tab1, tab2, tab3, tab4 = st.tabs([
        "📄 Upload CSV", 
        "➕ Add New Entry", 
        "❌ Delete Entry",
        "🔄 Modify Entry"
    ])

    # --- Tab 1: Upload CSV ---
    with tab1:
        with st.expander("⬆️ Upload Section", expanded=False):
            upload_csv_to_table(
                upload_label="📄 Upload Asset Data to `assets_table`",
                required_columns=[
                    "asset_id", "vni_asset_number", "license_id", "category", "manufacturer", "description",
                    "project_name", "domain_name", "team_name", "current_user_id", "status",
                    "expiry_date", "calibration_date", "verified_by", "added_on"
                ],
                db_table_name="assets_table",
                parse_dates=["expiry_date", "calibration_date", "added_on"]
            )

            upload_csv_to_table(
                upload_label="📄 Upload License Data to `license_table`",
                required_columns=["license_id", "duration_days", "duration_hours", "justification"],
                db_table_name="license_table"
            )

    # --- Tab 2: Add New Entry ---
    with tab2:
        with st.expander("➕ Add New Asset", expanded=False):
            with st.form("add_asset_form"):
                st.subheader("➕ Add New Asset")

                col1, col2 = st.columns(2)
                with engine.connect() as conn:
                    def fetch_unique(col):
                        result = conn.execute(text(f"SELECT DISTINCT {col} FROM assets_table WHERE {col} IS NOT NULL"))
                        return sorted([row[0] for row in result if row[0]])

                    suggestions = {
                        "vni_asset_number": fetch_unique("vni_asset_number"),
                        "category": fetch_unique("category"),
                        "manufacturer": fetch_unique("manufacturer"),
                        "project_name": fetch_unique("project_name"),
                        "domain_name": fetch_unique("domain_name"),
                        "team_name": fetch_unique("team_name")
                    }

                with col1:
                    vni_asset_number = dropdown_with_new("VNI Asset Number", suggestions["vni_asset_number"], "vni")
                    license_id = st.text_input("License ID")
                    category = dropdown_with_new("Category", suggestions["category"], "cat")
                    manufacturer = dropdown_with_new("Manufacturer", suggestions["manufacturer"], "manu")
                    description = st.text_area("Description")

                with col2:
                    project_name = dropdown_with_new("Project Name", suggestions["project_name"], "proj")
                    domain_name = dropdown_with_new("Domain Name", suggestions["domain_name"], "dom")
                    team_name = dropdown_with_new("Team Name", suggestions["team_name"], "team")
                    current_user_id = st.text_input("Current User ID")
                    status = st.selectbox("Status", ["Active", "Inactive", "Retired", "Under Maintenance", "Other"])

                expiry_date = st.date_input("Expiry Date")
                calibration_date = st.date_input("Calibration Date")
                verified_by = st.text_input("Verified By")

                submit_button = st.form_submit_button("Submit")

                if submit_button:
                    try:
                        with engine.connect() as conn:
                            insert_query = text("""
                                INSERT INTO assets_table (
                                    vni_asset_number, license_id, category, manufacturer,
                                    description, project_name, domain_name, team_name,
                                    current_user_id, status, expiry_date, calibration_date, verified_by
                                ) VALUES (
                                    :vni_asset_number, :license_id, :category, :manufacturer,
                                    :description, :project_name, :domain_name, :team_name,
                                    :current_user_id, :status, :expiry_date, :calibration_date, :verified_by
                                )
                            """)

                            conn.execute(insert_query, {
                                "vni_asset_number": vni_asset_number,
                                "license_id": license_id,
                                "category": category,
                                "manufacturer": manufacturer,
                                "description": description,
                                "project_name": project_name,
                                "domain_name": domain_name,
                                "team_name": team_name,
                                "current_user_id": current_user_id,
                                "status": status,
                                "expiry_date": pd.to_datetime(expiry_date),
                                "calibration_date": pd.to_datetime(calibration_date),
                                "verified_by": verified_by
                            })
                            conn.commit()
                            st.success("✅ New asset added successfully!")
                    except Exception as e:
                        st.error(f"❌ Error adding asset: {e}")

    # --- Tab 3: Delete Entry ---
    with tab3:
        with st.expander("🗑️ Delete Asset", expanded=False):
            st.markdown("### Delete Asset Record")

            delete_id = st.number_input("Enter Asset ID to delete", min_value=1, step=1, format="%d")
            if st.button("❌ Delete Asset"):
                try:
                    with engine.begin() as conn:
                        result = conn.execute(text("DELETE FROM assets_table WHERE asset_id = :id"), {"id": delete_id})
                        if result.rowcount:
                            st.success(f"✅ Asset with ID {delete_id} deleted successfully.")
                        else:
                            st.warning(f"⚠️ No asset found with ID {delete_id}.")
                except Exception as e:
                    st.error(f"❌ Error deleting asset: {e}")
    with tab4:
        with st.expander("🔄 Modify Existing Asset", expanded=False):
            with engine.connect() as conn:
                asset_ids = pd.read_sql("SELECT asset_id FROM assets_table ORDER BY asset_id", conn)["asset_id"].tolist()

            selected_id = st.selectbox("Select Asset ID to Modify", asset_ids)

            if selected_id:
                with engine.connect() as conn:
                    asset_data = pd.read_sql(
                        text("SELECT * FROM assets_table WHERE asset_id = :id"),
                        conn,
                        params={"id": selected_id}
                    ).iloc[0]

                with st.form("modify_asset_form"):
                    st.write(f"Editing Asset ID: {selected_id}")

                    col1, col2 = st.columns(2)
                    with col1:
                        vni_asset_number = st.text_input("VNI Asset Number", value=asset_data["vni_asset_number"])
                        license_id = st.text_input("License ID", value=asset_data["license_id"])
                        category = st.text_input("Category", value=asset_data["category"])
                        manufacturer = st.text_input("Manufacturer", value=asset_data["manufacturer"])
                        description = st.text_area("Description", value=asset_data["description"] or "")

                    with col2:
                        project_name = st.text_input("Project Name", value=asset_data["project_name"])
                        domain_name = st.text_input("Domain Name", value=asset_data["domain_name"])
                        team_name = st.text_input("Team Name", value=asset_data["team_name"])
                        current_user_id = st.text_input("Current User ID", value=asset_data["current_user_id"])
                        status = st.selectbox("Status", ["Active", "Inactive", "Retired", "Under Maintenance", "Other"], index=["Active", "Inactive", "Retired", "Under Maintenance", "Other"].index(asset_data["status"]))

                    expiry_date = st.date_input("Expiry Date", value=pd.to_datetime(asset_data["expiry_date"]))
                    calibration_date = st.date_input("Calibration Date", value=pd.to_datetime(asset_data["calibration_date"]))
                    verified_by = st.text_input("Verified By", value=asset_data["verified_by"])

                    update_button = st.form_submit_button("Update Record")

                    if update_button:
                        try:
                            with engine.begin() as conn:
                                update_query = text("""
                                    UPDATE assets_table SET
                                        vni_asset_number = :vni_asset_number,
                                        license_id = :license_id,
                                        category = :category,
                                        manufacturer = :manufacturer,
                                        description = :description,
                                        project_name = :project_name,
                                        domain_name = :domain_name,
                                        team_name = :team_name,
                                        current_user_id = :current_user_id,
                                        status = :status,
                                        expiry_date = :expiry_date,
                                        calibration_date = :calibration_date,
                                        verified_by = :verified_by
                                    WHERE asset_id = :asset_id
                                """)

                                conn.execute(update_query, {
                                    "asset_id": selected_id,
                                    "vni_asset_number": vni_asset_number,
                                    "license_id": license_id,
                                    "category": category,
                                    "manufacturer": manufacturer,
                                    "description": description,
                                    "project_name": project_name,
                                    "domain_name": domain_name,
                                    "team_name": team_name,
                                    "current_user_id": current_user_id,
                                    "status": status,
                                    "expiry_date": pd.to_datetime(expiry_date),
                                    "calibration_date": pd.to_datetime(calibration_date),
                                    "verified_by": verified_by
                                })

                            st.success("✅ Asset updated successfully!")
                        except Exception as e:
                            st.error(f"❌ Error updating asset: {e}")
else:
    st.warning("🔐 Only admins are allowed to upload asset/license data.")

st.markdown("## 🔍 Filtered Asset List")

# --- Fetch Data from DB ---
try:
    with engine.connect() as conn:
        df_assets = pd.read_sql("SELECT * FROM assets_table", conn)

except Exception as e:
    st.error(f"❌ Failed to load asset data: {e}")
    st.stop()

# --- Define Filters ---
with st.expander("🧰 Apply Filters", expanded=True):
    search_query = st.text_input("🔍 Search Text (applies to all columns)", "")
    col1, col2, col3 = st.columns(3)
    
    def get_options(column):
        opts = sorted(df_assets[column].dropna().unique().tolist())
        return ["All", "None"] + opts
    
    with col1:
        project_filter = st.selectbox("Project Name", get_options("project_name"))

        # Prepare license options with All + None
        license_values = get_options("license_id")
        license_options = ["All", "None"] + license_values

        # Multiselect for license_id with default as "All"
        selected_licenses = st.multiselect(
            "License ID", 
            license_options, 
            default=["All"]
        )

        # Optional: Expand "All" into all actual values for filtering
        if selected_licenses == ["All"]:
            selected_licenses = license_values

        vni_filter = st.selectbox("VNI Asset Number", get_options("vni_asset_number"))
        
    with col2:
        # team_filter = st.selectbox("Team Name", ["All"] + sorted(df_assets["team_name"].dropna().unique().tolist()))
        team_filter = st.selectbox("Team Name", get_options("team_name"))
        # domain_filter = st.selectbox("Domain Name", ["All"] + sorted(df_assets["domain_name"].dropna().unique().tolist()))
        domain_filter = st.selectbox("Domain Name", get_options("domain_name"))
        # user_filter = st.selectbox("Current User ID", ["All"] + sorted(df_assets["current_user_id"].dropna().unique().tolist()))
        user_filter = st.selectbox("Current User ID", get_options("current_user_id"))
    with col3:
        category_filter = st.selectbox("Category", get_options("category"))
        # category_filter = st.selectbox("Category", ["All"] + sorted(df_assets["category"].dropna().unique().tolist()))
        # manufacturer_filter = st.selectbox("Manufacturer", ["All"] + sorted(df_assets["manufacturer"].dropna().unique().tolist()))
        manufacturer_filter = st.selectbox("Manufacturer", get_options("manufacturer"))

# --- Apply Filter Logic ---
filtered_df = df_assets.copy()

def apply_filter(df, column, value):
    if isinstance(value, list):
        if "All" in value:
            return df
        elif "None" in value:
            # Filter rows where column is null or value is in the list (excluding "None")
            actual_values = [v for v in value if v != "None"]
            if actual_values:
                return df[df[column].isna() | df[column].isin(actual_values)]
            else:
                return df[df[column].isna()]
        else:
            return df[df[column].isin(value)]
    elif value == "All":
        return df
    elif value == "None":
        return df[df[column].isna()]
    else:
        return df[df[column] == value]
    
filtered_df = apply_filter(filtered_df, "project_name", project_filter)
filtered_df = apply_filter(filtered_df, "license_id", selected_licenses)
filtered_df = apply_filter(filtered_df, "vni_asset_number", vni_filter)
filtered_df = apply_filter(filtered_df, "team_name", team_filter)
filtered_df = apply_filter(filtered_df, "domain_name", domain_filter)
filtered_df = apply_filter(filtered_df, "current_user_id", user_filter)
filtered_df = apply_filter(filtered_df, "category", category_filter)
filtered_df = apply_filter(filtered_df, "manufacturer", manufacturer_filter)

# --- Apply global search if search_query is not empty ---
if search_query:
    search_query_lower = search_query.lower()
    filtered_df = filtered_df[
        filtered_df.astype(str).apply(lambda row: row.str.lower().str.contains(search_query_lower)).any(axis=1)
    ]
    
# --- Show Filtered Table ---
st.markdown(f"### 📋 Filtered Results ({len(filtered_df)} rows)")
st.dataframe(filtered_df, use_container_width=True)