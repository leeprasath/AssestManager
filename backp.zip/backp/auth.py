import os
import streamlit as st

def is_admin():
    return st.session_state.get("role") == "admin"

def require_windows_login():
    user = os.getlogin().lower()  # Normalize case

    st.session_state.logged_in = True
    st.session_state.username = user

    # ✅ Admins: uif74417 and uif52311
    if user in ["uif74417", "uif52311"]:
        st.session_state.role = "admin"
        # st.button("Upload CSV")
    else:
        st.session_state.role = "user"

    st.info(f"✅ Logged in as: {user} ({st.session_state.role})")
