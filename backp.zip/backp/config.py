# config.py

DATABASE_URL = "postgresql+psycopg2://postgres@localhost:5432/postgres"