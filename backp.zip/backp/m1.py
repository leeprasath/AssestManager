# main.py
import streamlit as st
import pandas as pd
import plotly.express as px
from sqlalchemy import create_engine
from config import DATABASE_URL
from auth import require_windows_login  # Updated to Windows login

# import pages.asset_list as asset_list

# 🔐 Windows login
require_windows_login()

# 🔧 Page config
st.set_page_config(page_title="Asset Management Dashboard", layout="wide", page_icon="📊")

st.title("🏠 Asset Management Dashboard")

# Optional: Sidebar content
with st.sidebar:
    st.markdown("### 📚 Navigation")
    st.markdown("Use the sidebar to select a page.")

# Connect to your PostgreSQL DB
engine = create_engine(DATABASE_URL)

# Load assets and license data
@st.cache_data(ttl=300)
def load_data():
    df_assets = pd.read_sql("SELECT * FROM assets_table", engine)
    df_licenses = pd.read_sql("SELECT * FROM license_table", engine)
    return df_assets, df_licenses

df_assets, df_licenses = load_data()

# Summary metrics
col1, col2, col3 = st.columns(3)
col1.metric("🔢 Total Assets", len(df_assets))
col2.metric("🟢 Assets In Use", df_assets["status"].value_counts().get("in_use", 0))
col3.metric("⚪ Available Assets", df_assets["status"].value_counts().get("available", 0))

# License Usage Summary
st.subheader("📈 License Usage Summary")
if not df_licenses.empty and "duration_days" in df_licenses.columns:
    fig = px.histogram(df_licenses, x="duration_days", nbins=10, title="License Usage Distribution")
    st.plotly_chart(fig, use_container_width=True)

# Recently Added Assets
st.subheader("🕒 Recently Added Assets")
if "added_on" in df_assets.columns:
    recent_assets = df_assets.sort_values(by="added_on", ascending=False).head(10)
    st.dataframe(recent_assets, use_container_width=True)
else:
    st.warning("'added_on' column not found in assets_table.")
