# main.py
import streamlit as st
import pandas as pd
import plotly.express as px
from sqlalchemy import create_engine
from config import DATABASE_URL
from auth import require_windows_login  # Windows login auth

# 🔐 Enforce Windows login
require_windows_login()

# 🔧 Page config
st.set_page_config(page_title="Asset Management Dashboard", layout="wide", page_icon="📊")
st.title("🏠 Asset Management Dashboard")

# 👉 Sidebar Navigation
with st.sidebar:
    st.markdown("### 📚 Navigation")
    st.markdown("Use the sidebar to select a page.")

# 🛠️ DB connection
engine = create_engine(DATABASE_URL)

# 🧠 Load asset and license data
@st.cache_data(ttl=300)
def load_data():
    df_assets = pd.read_sql("SELECT * FROM assets_table", engine)
    df_licenses = pd.read_sql("SELECT * FROM license_table", engine)
    return df_assets, df_licenses

df_assets, df_licenses = load_data()

# 📊 Summary Metrics Calculation
total_assets = len(df_assets)
assets_in_use = df_assets["status"].str.lower().value_counts().get("in_use", 0)
unique_licenses_in_use = df_assets["license_id"].dropna().nunique()
required_columns = ["vni_asset_number", "category", "manufacturer", "project_name", "license_id"]
incomplete_assets_count = df_assets[required_columns].isnull().any(axis=1).sum()

# 💡 Styled Summary Line (Single Row)
summary_html = f"""
<style>
.summary-container {{
    display: flex;
    justify-content: space-between;
    font-size: 16px;
    font-weight: 500;
    background-color: #f9f9f9;
    padding: 10px 20px;
    border-radius: 10px;
    border: 1px solid #ddd;
    margin-bottom: 1.5rem;
}}
.summary-item {{
    flex: 1;
    text-align: center;
}}
.metric-label {{
    color: #444;
}}
.metric-value {{
    font-size: 20px;
    font-weight: bold;
    color: #0066cc;
}}
</style>

<div class="summary-container">
    <div class="summary-item">
        <div class="metric-label">Total Assets</div>
        <div class="metric-value">{total_assets}</div>
    </div>
    <div class="summary-item">
        <div class="metric-label">Vector Licenses in Use</div>
        <div class="metric-value">{unique_licenses_in_use}</div>
    </div>
    <div class="summary-item">
        <div class="metric-label">Assets In Use</div>
        <div class="metric-value">{assets_in_use}</div>
    </div>
    <div class="summary-item">
        <div class="metric-label">Incomplete Records</div>
        <div class="metric-value">{incomplete_assets_count}</div>
    </div>
</div>
"""
st.markdown(summary_html, unsafe_allow_html=True)

# 📈 License Usage Visualization (duration_hours → duration_days)
st.subheader("📈 License Usage Summary")
if not df_licenses.empty:
    if "duration_hours" in df_licenses.columns:
        df_licenses["duration_days"] = df_licenses["duration_hours"] / 9  # Assuming 9 working hours per day
        fig = px.histogram(df_licenses, x="duration_days", nbins=10, title="License Usage (Days)")
        st.plotly_chart(fig, use_container_width=True)
    elif "duration_days" in df_licenses.columns:
        fig = px.histogram(df_licenses, x="duration_days", nbins=10, title="License Usage Distribution")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No 'duration_hours' or 'duration_days' column found in license_table.")
else:
    st.info("License data is empty.")

# 🕒 Recently Added Assets
st.subheader("🕒 Recently Added Assets")
if "added_on" in df_assets.columns:
    recent_assets = df_assets.sort_values(by="added_on", ascending=False).head(10)
    st.dataframe(recent_assets, use_container_width=True)
else:
    st.warning("'added_on' column not found in assets_table.")