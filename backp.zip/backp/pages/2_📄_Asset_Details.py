import streamlit as st
from auth import require_windows_login

require_windows_login()

st.title("📄 Asset Details")
st.info("🚧 This page is under construction.")