import psycopg2
import csv

# Database connection config
conn = psycopg2.connect(
    dbname="your_database_name",
    user="your_username",
    password="your_password",
    host="localhost",     # or your host
    port="5432"           # default PostgreSQL port
)
cur = conn.cursor()

# Create table (run only once)
create_table_query = """
CREATE TABLE IF NOT EXISTS asset_inventory (
    asset_id INTEGER PRIMARY KEY,
    vni_asset_number TEXT,
    license_id TEXT,
    category TEXT,
    manufacturer TEXT,
    description TEXT,
    project_name TEXT,
    domain_name TEXT,
    team_name TEXT,
    current_user_id TEXT,
    status TEXT,
    expiry_date DATE,
    calibration_date DATE,
    verified_by TEXT,
    added_on DATE
);
"""
cur.execute(create_table_query)
conn.commit()

# Load data from CSV
with open('assets.csv', mode='r', encoding='utf-8') as file:
    reader = csv.DictReader(file, delimiter='\t')  # Use '\t' if tab-separated
    for row in reader:
        cur.execute("""
            INSERT INTO asset_inventory (
                asset_id, vni_asset_number, license_id, category, manufacturer,
                description, project_name, domain_name, team_name, current_user_id,
                status, expiry_date, calibration_date, verified_by, added_on
            ) VALUES (
                %(asset_id)s, %(vni_asset_number)s, %(license_id)s, %(category)s, %(manufacturer)s,
                %(description)s, %(project_name)s, %(domain_name)s, %(team_name)s, %(current_user_id)s,
                %(status)s, %(expiry_date)s, %(calibration_date)s, %(verified_by)s, %(added_on)s
            )
            ON CONFLICT (asset_id) DO NOTHING;
        """, row)

conn.commit()
cur.close()
conn.close()
print("Data inserted successfully.")
