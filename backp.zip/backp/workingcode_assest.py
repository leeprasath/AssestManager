import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text
from config import DATABASE_URL
from auth import require_windows_login


# --------------------- 🔐 Login Required ---------------------
require_windows_login()

# --------------------- 📄 Page Config ---------------------
st.set_page_config(
    page_title="📦 Asset Upload Dashboard",
    page_icon="📦",
    layout="wide"
)

st.title("📦 Asset Upload Dashboard")

# --------------------- 🔌 Connect to DB ---------------------
try:
    engine = create_engine(DATABASE_URL)
    with engine.connect() as conn:
        df_assets = pd.read_sql("SELECT * FROM assets_table", conn)
        df_licenses = pd.read_sql("SELECT * FROM license_table", conn)
except Exception as e:
    st.error(f"❌ Failed to connect to database: {e}")
    st.stop()

# --------------------- 🔁 Reusable Upload Function ---------------------
def upload_csv_to_table(upload_label, required_columns, db_table_name, parse_dates=None):
    st.sidebar.header(upload_label)
    uploaded_file = st.sidebar.file_uploader(f"Upload CSV for {db_table_name}", type=["csv"], key=db_table_name)

    if uploaded_file:
        df_upload = pd.read_csv(uploaded_file)

        st.subheader(f"🔍 Preview of Uploaded Data for `{db_table_name}`")
        st.dataframe(df_upload.head(10), use_container_width=True)

        if not all(col in df_upload.columns for col in required_columns):
            st.error("❌ CSV is missing one or more required columns.")
            return

        try:
            # Parse date columns safely
            if parse_dates:
                for date_col in parse_dates:
                    df_upload[date_col] = pd.to_datetime(df_upload[date_col], errors="coerce")
            
            # Fix license_id: remove float `.0`, and convert NaN/None properly
            if "license_id" in df_upload.columns:
                df_upload["license_id"] = df_upload["license_id"].astype(str).str.replace(".0", "", regex=False)
                df_upload["license_id"] = df_upload["license_id"].replace(["nan", "None", "NaN", "null"], None)
            
            # Special handling for assets_table
            if db_table_name == "assets_table":
                df_upload.dropna(subset=["vni_asset_number"], inplace=True)    
            st.write(f"📦 Total records in file: {len(df_upload)}")
            
            with engine.begin() as conn:
                if db_table_name == "license_table":
                    conn.execute(text("DELETE FROM license_table"))

                elif db_table_name == "assets_table":
                    conn.execute(text("DELETE FROM assets_table"))            

                df_upload.to_sql(db_table_name, conn, if_exists="append", index=False)

            st.success(f"✅ Uploaded {len(df_upload)} records to `{db_table_name}`.")
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ Failed to insert into `{db_table_name}`: {e}")   

# --------------------- 📤 Upload Sections ---------------------
if st.session_state.role == "admin":
    # Upload for assets_table
    upload_csv_to_table(
        upload_label="📤 Upload Assets Data",
        required_columns=[
            "asset_id", "vni_asset_number", "license_id", "category", "manufacturer", "description",
            "project_name", "domain_name", "team_name", "current_user_id", "status",
            "expiry_date", "calibration_date", "verified_by", "added_on"
        ],
        db_table_name="assets_table",
        parse_dates=["expiry_date", "calibration_date", "added_on"]
    )

    # Upload for license_table
    upload_csv_to_table(
        upload_label="📥 Upload License Data",
        required_columns=["license_id", "duration_days", "duration_hours", "justification"],
        db_table_name="license_table"
    )

# --------------------- 📋 Existing Tables Preview ---------------------
st.subheader("📋 Existing Records in `assets_table`")
st.dataframe(df_assets.head(50), use_container_width=True)

st.subheader("📋 Existing Records in `license_table`")
st.dataframe(df_licenses.head(50), use_container_width=True)
